api_key = "r60vqHHmENNaOVLuKn1JXZbvbLc4AVGVxJdDTb2KuHWtrUPdFKvV2RvOnGiHq1l2"
secret_key = "xTVZJjYSpa0AKqXnscKw4PTIpkPT242hozDy2YSUozQBCKF0yPIglotXbgIO60Up"



BNBBUSD = {
	"symbol" : "BNBBUSD", 

	"coin1" : {
		"symbol" : "BNB",
		"increment" : 0.001,
		"dp" : 3,
	},

	"coin2" : {
		"symbol" : "USDT",
		"amount" : 10,
		"dp" : 1
	},

	"market" : {
		"increment" : 10
	}
}

XNOBUSD = {
	"symbol" : "XNOBUSD",

	"coin1" : {
		"symbol" : "XNO",
		"increment" : 0.01,
		"dp" : 2,
	},

	"coin2" : {
		"symbol" : "BUSD",
		"amount" : 10,
		"dp" : 3
	},

	"market" : {
		"increment" : 0.01
	}
}

import config as cf
import pandas as pd
import binance
import time

class PlaceOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)

		self.pair = pair
		self.symbol = pair["symbol"]

		self.coin1 = pair["coin1"]
		self.coin2 = pair["coin2"]
		self.market = pair["market"]

		self.increment = pair["market"]["increment"]

		self.isIsolated = True
		self.df3 = pd.read_csv("data3.csv")

		self.main()

		def remove_order(self, i):
			with Lock():
				df = self.df3
				df = df[df["orderId"] != i]
				df.to_csv("data3.csv", index=False)

		def get_market_price(self):
			key = f"https://api.binance.com/api/v3/ticker/price?symbol={self.symbol}"

			data = requests.get(key)  
			data = data.json()
			print(f"{data['symbol']} price is {data['price']}")

			return float(data["price"])

		def get_amount_coin(self, order_price):
			coin1 = self.coin2["amount"] / order_price

			calculated_coin1 = coin1 * order_price

			if coin1 < self.coin2["amount"]:
				coin1 += self.coin1["increment"]
			return round(coin1, self.coin1["dp"])

		def create_margin_buy_order(self, order_price):
			order = self.client.create_margin_order(
				    symbol=self.symbol,
				    side="BUY",
			        type="LIMIT",
			        timeInForce="GTC",
				    quantity=self.get_amount_coin(order_price),
				    price=order_price,
					isIsolated=self.isIsolated)

		def create_margin_sell_order(self, order_price):
			order = self.client.create_margin_order(
				    symbol=self.symbol,
				    side="SELL",
			        type="LIMIT",
			        timeInForce="GTC",
				    quantity=self.get_amount_coin(order_price),
				    price=order_price,
					isIsolated=self.isIsolated)

		def process_order(self):
			pd = self.df3

			order = df[
						(df["symbol"] == self.symbol) & 
						(df["status"] == "FILLED")
						] #get all the id with a certain pair

			if not order.empty:
				orderId = order["orderId"]

				for i in orderId:
					order = self.client.get_order(symbol=self.symbol, orderId=i)
					
					if order["status"] != "FILLED":
						self.remove_order(i)

					elif order["status"] == "FILLED":
						with Lock():
							df = self.df3
							row_index = df[df["orderId"] == i].index #get index of the row that the orderId is FILLED
							df.loc[row_index, "status"] = "FILLED" #replace cell with FILLED by rowindex and status
							df.to_csv("data3.csv", index=False) #write to csv

		def get_open_order(self):
			open_order = self.client.get_open_margin_orders(symbol=self.symbol, isIsolated=self.isIsolated)
		
			self.open_buy_order = [float(order['price']) for order in open_order if order['side'] == 'BUY']
			self.open_sell_order = [float(order['price']) for order in open_order if order['side'] == 'SELL']

		# def check_open_margin_buy_order(self): #check if order still present after placed order, sometimes market price moved too quick, order filled without taken by snap
		# 	pass

		# def check_open_margin_sell_order(self):
		# 	pass

		def open_margin_buy_order(self):
			pass

		def open_margin_sell_order(self):
			pass

		def open_margin_order(self):
				order = df[(df["symbol"] == self.symbol) & (df["status"] == "FILLED")] #get all the id with a certain pair

				if not order.empty:
					for i in order.index:
						side = order.loc[i,"side"]
						orderId = order.loc[i,"orderId"]
						price = order.loc[i,"price"]
						market_price = self.get_market_price()

						print(f"side: {side}")
						print(f"orderId: {orderId}")
						print(f"order price: {price}")
						print(f"market price: {market_price}")

				if side == "SELL":
					buy_price = round(price - self.market["increment"], self.coin2["dp"])
					print(f"buy price: {buy_price}")

					if buy_price < market_price:
						print("place buy")
						self.create_margin_buy_order(buy_price)
						self.get_open_order()

						if not buy_price in self.open_buy_order:
							pass
							#check if order present, if not present, order filled, place order

					elif buy_price >= market_price:
						#check posistion if position has order move down and then record it after place order
						self.get_open_order()

						while buy_price in self.open_buy_order:
							buy_price -= self.market["increment"]
						else:
							self.create_margin_buy_order(buy_price)

				elif side == "BUY":
					sell_price = round(price + self.market["increment"], self.coin2["dp"])
					print(f"sell price: {sell_price}")

					if sell_price > market_price:
						print("place sell")
						self.create_margin_sell_order(sell_price)
						self.get_open_order()

						if not sell_price in self.open_sell_order:
							pass

					elif sell_price <= market_price:
						self.get_open_order()

						while sell_price in self.open_sell_order:
							sell_price += self.market["increment"]
						else:
							self.create_margin_sell_order(sell_price)

		def main(self):
			self.process_order()
			self.open_margin_order()

class GetOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)
		self.symbol = pair["symbol"]
		self.df1 = "data1.csv"
		self.df2 = "data2.csv"
		self.df3 = "data3.csv"

		self.main()

	def get_open_orders(self, data_file):
		orders = self.client.get_open_orders(symbol=self.symbol)

		df = pd.DataFrame(orders)
		df.to_csv(data_file, index=False)

	def compare(self, data1, data2):
		try:
			df1 = pd.read_csv(data1)
			df2 = pd.read_csv(data2)

			result = df1[~df1.apply(tuple,1).isin(df2.apply(tuple,1))]

			if not result.empty:
				print(result)
				with Lock():
					result.to_csv(self.df3, header=False, index=False, mode="a")

		except pd.errors.EmptyDataError:
			print("No orders")
			return

	def main(self):
		while True:
			try:
				time.sleep(0.5)
				self.get_open_orders(self.df1)
				self.compare(self.df2, self.df1)

				time.sleep(0.5)
				self.get_open_orders(self.df2)
				self.compare(self.df1, self.df2)

			except Exception as e:
				print(e)
				time.sleep(5)


#replacing orders, for example sell 100, buy 99, market price 99, open order from 98 to 95, 
#place order at 94, but market price is 101, 99 missing, replace 94 to 99 
class ReplaceOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)
		self.symbol = pair["symbol"]
		self.df4 = pd.read_csv("data4.csv")
		
		self.main()

	def main():
		pass
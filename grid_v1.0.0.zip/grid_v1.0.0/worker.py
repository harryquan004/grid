import config as cf
import pandas as pd
import binance
import time

#replacing orders, for example sell 100, buy 99, market price 99, open order from 98 to 95, 
#place order at 94, but market price is 101, 99 missing, replace 94 to 99 
class ReplaceOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)
		self.symbol = pair["symbol"]
		self.df4 = pd.read_csv("data4.csv")
		
	def main():
		pass


class PlaceOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)
		self.symbol = pair["symbol"]
		self.isIsolated = True
		self.df3 = pd.read_csv("data3.csv")

		self.main()

		def remove_order(self, i):
			with Lock():
				df = self.df3
				df = df[df["orderId"] != i]
				df.to_csv("data3.csv", index=False)

		def get_market_price(self):
			key = f"https://api.binance.com/api/v3/ticker/price?symbol={self.symbol}"

			data = requests.get(key)  
			data = data.json()
			print(f"{data['symbol']} price is {data['price']}")

			return float(data["price"])

		def get_amount_coin(self, order_price):
			coin1 = self.coin2["amount"] / order_price

			calculated_coin1 = coin1 * order_price

			if coin1 < self.coin2["amount"]:
				coin1 += self.coin1["increament"]
			return round(coin1, self.coin1["dp"])

		def verify_filled_order(self):
			df = self.df3
			order = df[(df["symbol"] == self.symbol) & (df["status"] != "FILLED")]

			if not order.empty:
				orderId = order["orderId"]

				for i in orderId:
					order = self.client.get_order(symbol=self.symbol, orderId=i)
					
					if order["status"] != "FILLED":
						self.remove_order(i)

					elif order["status"] == "FILLED":
						with Lock():
							# df = pd.read_csv(self.df3)
							row_index = df[df["orderId"] == i].index #get index of the row that the orderId is FILLED
							df.loc[row_index, "status"] = "FILLED" #replace cell with FILLED by rowindex and status
							df.to_csv("data3.csv", index=False) #write to csv

		def create_margin_buy_order(self, order_price):
			order = self.client.create_margin_order(
				    symbol=self.symbol,
				    side="BUY",
			        type="LIMIT",
			        timeInForce="GTC",
				    quantity=self.get_amount_coin(order_price),
				    price=order_price,
					isIsolated=self.isIsolated)

		def create_margin_sell_order(self, order_price):
			order = self.client.create_margin_order(
				    symbol=self.symbol,
				    side="SELL",
			        type="LIMIT",
			        timeInForce="GTC",
				    quantity=self.get_amount_coin(order_price),
				    price=order_price,
					isIsolated=self.isIsolated)

		def place_order(self):
			pd = self.df3

			order = df[
						(df["symbol"] == self.symbol) & 
						(df["status"] == "FILLED")
						] #get all the id with a certain pair

			if not order.empty:
				pass


		def main(self):
			self.process_order()


class GetOrders:
	def __init__ (self, pair):
		self.client = binance.Client(cf.api_key, cf.secret_key)
		self.symbol = pair["symbol"]
		self.df1 = "data1.csv"
		self.df2 = "data2.csv"
		self.df3 = "data3.csv"

		self.main()

	def get_open_orders(self, data_file):
		orders = self.client.get_open_orders(symbol=self.symbol)

		df = pd.DataFrame(orders)
		df.to_csv(data_file, index=False)

	def compare(self, data1, data2):
		try:
			df1 = pd.read_csv(data1)
			df2 = pd.read_csv(data2)

			result = df1[~df1.apply(tuple,1).isin(df2.apply(tuple,1))]

			if not result.empty:
				print(result)
				with Lock():
					result.to_csv(self.df3, header=False, index=False, mode="a")

		except pd.errors.EmptyDataError:
			print("No orders")
			return

	def main(self):
		while True:
			try:
				time.sleep(0.5)
				self.get_open_orders(self.df1)
				self.compare(self.df2, self.df1)

				time.sleep(0.5)
				self.get_open_orders(self.df2)
				self.compare(self.df1, self.df2)
			except Exception as e:
				print(e)
				time.sleep(5)
			
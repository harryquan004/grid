from threading import Thread, Lock 
from binance import Client
import config as cf
from worker import *
import time

def main(pair):
	profiles = []
	
	for i in pair:
		profiles += [
					Thread(target=GetOrders, args=[i]), 
					Thread(target=PlaceOrders, args=[i])
					]

	for t in profiles:
		t.start()
	for t in profiles:
		t.join()

if __name__ == "__main__":
	pair = [cf.XNOBUSD]
	print("Start")
	main(pair)

#make sure account balance is enough before making order
#when running multiple coin, lower the snapshot rate
	
api_key = "r60vqHHmENNaOVLuKn1JXZbvbLc4AVGVxJdDTb2KuHWtrUPdFKvV2RvOnGiHq1l2"
secret_key = "xTVZJjYSpa0AKqXnscKw4PTIpkPT242hozDy2YSUozQBCKF0yPIglotXbgIO60Up"


BNBUSDT = {
	"symbol" : "BNBUSDT", 

	"coin1" : {
		"symbol" : "BNB",
		"increament" : 0.001,
		"dp" : 3,
	},

	"coin2" : {
		"symbol" : "USDT",
		"amount" : 10,
	},

	"market" : {
		"increament" : 10
	}
}

XNOBUSD = {
	"symbol" : "XNOBUSD",

	"coin1" : {
		"symbol" : "XNO",
		"increament" : 0.01,
		"dp" : 2,
	},

	"coin2" : {
		"symbol" : "BUSD",
		"amount" : 10,
	},

	"market" : {
		"increament" : 0.01
	}
}

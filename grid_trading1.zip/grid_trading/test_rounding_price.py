import config as cf
class Test:
	def __init__ (self, pair):
		self.pair = pair
		self.symbol = pair["symbol"]

		self.coin1 = pair["coin1"]
		self.coin2 = pair["coin2"]
		self.market = pair["market"]

		self.increment = pair["market"]["increment"]

		self.open_margin_sell_order()

	def open_margin_order(self):
		price = 100.5
		print(f"""{self.coin1["dp"]},{self.coin2["dp"]}""")
		buy_price = round(price - self.market["increment"], self.coin2["dp"])
			
		print(buy_price)

	def open_margin_sell_order(self): 
		side = "BUY"
		price = 310.0
		market_price = 320
		self.open_sell_order = [320,330,340,350] 

		if side == "BUY":
			sell_price = round(price + self.market["increment"], self.coin2["dp"])
			print(f"sell price: {sell_price}")

		if sell_price > market_price:
			# self.create_margin_sell_order(sell_price)
			print(f"create margin sell order: {sell_price}\
				market price: {market_price}")

			# self.get_open_order()
			print(f"open sell order: {self.open_sell_order}")

			if not sell_price in self.open_sell_order:
				pass

		elif sell_price <= market_price:
			# self.get_open_order()
			print(f"open sell order: {self.open_sell_order}")

			while sell_price in self.open_sell_order:
				sell_price += self.market["increment"]
			else:
				# self.create_margin_sell_order(sell_price)
				print(f"create margin sell order: {sell_price}\
				market price: {market_price}")


Test(cf.BNBBUSD)

